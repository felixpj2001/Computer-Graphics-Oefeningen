// RayTracer.cpp: implementation of the RayTracer class.
//
//////////////////////////////////////////////////////////////////////

#include "RayTracer.h"
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------

RayTracer::RayTracer()
{
	m_ImageWidth = 0;
	m_ImageHeight = 0;

	m_UseMultipleRays = false;
}
//--------------------------------------------------------------------
RayTracer::RayTracer(cg_Canvas* canv)
{
	m_ImageWidth = 0;
	m_ImageHeight = 0;

	m_UseMultipleRays = false;

	canvas = canv;
}
//--------------------------------------------------------------------
RayTracer::~RayTracer()
{
	
}
//--------------------------------------------------------------------
void RayTracer::slotRender()
{
	TraceView();
}
//--------------------------------------------------------------------
void RayTracer::TraceView()
{
	printf("Tracing... ");
	for(int y = m_ImageHalfHeight; y > -m_ImageHalfHeight; y--)
	{
		for(int x = -m_ImageHalfWidth; x < m_ImageHalfWidth; x++)
		{			
			if(m_UseMultipleRays)
			{
				// nog niet van toepassing
			}
			else
			{
				RGB_Color Pixelcolor = RGB_Color(0,0,0);	//AANPASSEN!
				

				// kleur van de pixel doorgeven aan de canvas:
				canvas->PutPixel(x, y, Pixelcolor);
				// pixel onder de huidige positie rood kleuren om progress te tonen:
				if(y > -m_ImageHalfHeight + 1)
				{
					canvas->PutPixel(x, y-1, RGB_Color(1,0,0));
				}
			}
			//canvas->repaint(); //pixel per pixel update: SLOW 
		}
		canvas->repaint(); //line per line update: MEDIUM SPEED 
	}
	//canvas->repaint(); // update complete image once: FASTER 
	printf("done.\n");
}
//--------------------------------------------------------------------
void RayTracer::slotSizeChanged(int NewW, int NewH)
{
	m_ImageWidth = NewW;
	m_ImageHeight = NewH;
	m_ImageHalfWidth = m_ImageWidth / 2;
	m_ImageHalfHeight = m_ImageHeight / 2;
}

//--------------------------------------------------------------------
