#include "cg_MainWindow.h"
#include <QPainter>
#include <stdio.h>

//--------------------------------------------------------------------
cg_MainWindow::cg_MainWindow()
{
	ui = new Ui_CG_Window();
	ui->setupUi(this);

	m_RayTracer = new RayTracer(ui->drawCanvas);
	m_UseMultipleRays = false;

	connect(ui->pushButton_Save, SIGNAL(clicked()), ui->drawCanvas, SLOT(slotSaveImage()));
	connect(ui->pushButton_Render, SIGNAL(clicked()), m_RayTracer, SLOT(slotRender()));
	connect(ui->pushButton_Mode, SIGNAL(clicked()), this, SLOT(slotChangeMode()));
	connect(ui->drawCanvas, SIGNAL(signalSizeChanged(int, int)), m_RayTracer, SLOT(slotSizeChanged(int, int)));
	
}
//--------------------------------------------------------------------
cg_MainWindow::~cg_MainWindow()
{
	delete ui;
	delete m_RayTracer;
}
//--------------------------------------------------------------------
void cg_MainWindow::slotChangeMode()
{
	m_UseMultipleRays = !m_UseMultipleRays;
	printf("Sample mode changed.\n");
	if(m_UseMultipleRays)
	{
		m_RayTracer->useMultipleRays(true);
		ui->pushButton_Mode->setText("  multiple samples / pixel   ");	
	}
	else
	{
		m_RayTracer->useMultipleRays(false);
		ui->pushButton_Mode->setText("  1 sample / pixel   ");
		
	}
}
//--------------------------------------------------------------------
