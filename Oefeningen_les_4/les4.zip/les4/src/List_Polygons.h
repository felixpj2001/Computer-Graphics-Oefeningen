#pragma once

#include "Object_Polygon.h"
#include <vector>

class List_Polygons
{
public:
    std::vector<Object_Polygon> m_polygons;

};