#pragma once

#include "Object_Object.h"
#include <vector>

class List_Objects
{
public:
    std::vector<Object_Object> m_objects;

};