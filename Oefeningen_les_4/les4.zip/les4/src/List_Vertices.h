#pragma once

#include "Object_Vertex.h"
#include <vector>

class List_Vertices
{
public:
    std::vector<Object_Vertex> m_vertices;

};